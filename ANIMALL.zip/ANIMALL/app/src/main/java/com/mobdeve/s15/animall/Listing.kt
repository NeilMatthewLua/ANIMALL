package com.mobdeve.s15.animall

import android.graphics.Bitmap
import android.net.Uri

class Listing(val filename: String, val imageURI: Uri, val imageBitmap: Bitmap)
