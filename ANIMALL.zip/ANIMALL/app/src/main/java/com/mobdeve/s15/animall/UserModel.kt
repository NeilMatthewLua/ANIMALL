package com.mobdeve.s15.animall

class UserModel (
    val email: String,
    val name: String,
    val preferredLocation: String
)